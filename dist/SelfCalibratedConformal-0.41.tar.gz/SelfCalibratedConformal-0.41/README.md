# Self-Calibrated Conformal Prediction: bridging calibration and predictive inference
